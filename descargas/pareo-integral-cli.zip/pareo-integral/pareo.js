#!/usr/bin/env node
// Pareo Integral, línea de comandos. Ver README.md (English) o LEEME.md (español).
"use strict";
const { principal } = require("./js/pareo/cli.js");
principal(process.argv.slice(2)).then(
  (codigo) => process.exit(codigo),
  (e) => { process.stderr.write(String((e && e.stack) || e) + "\n"); process.exit(2); }
);
